# Swa-Koteka Foundations Web Platform

## Student Information
- **Name:** Vukosi Uginie Shivuri
- **Student ID:** ST10505758
- **Module:**  WEDE5020  / Web Development Part 1

## Project Overview
A web platform designed for Swa-Koteka Foundations, a non-profit organization based in Ndindani village, South Africa. The platform addresses their lack of digital footprint by establishing channels for volunteer applications, donation inquiries, career listings, and organizational transparency.

## Website Goals & Objectives
- Establish an active online presence for rural community outreach.
- Streamline volunteer and donor registration.
- Publish primary core focus areas (Education, Women Empowerment, Community Advocacy).

## Sitemap
1. `index.html` - Homepage with core focus areas and call to action.
2. `about.html` - History, vision, mission, and beneficiaries.
3. `services.html` - Detailed operational programs.
4. `enquiry.html` - Integrated form for volunteering, donations, and careers.
5. `contact.html` - Operational locations and contact form.

## Changelog
- **Part 1 Submission:** Initial project structure setup, HTML5 semantic layout, form elements, and basic site routing.

## Changelog
### Part 2 Updates
- External Stylesheet Created**: Added `style.css` under the `css/` directory to manage global layouts, color schemes, and typography.
- Responsive Design Implemented**: Configured media queries for tablet (max-width: 900px) and mobile (max-width: 600px) viewports, switching grid setups to single-column flows.
- Visual Enhancements**: Added interactive `:hover` and `:focus` states to navigation links and buttons, applying consistent relative units (`rem`, `%`).
- HTML Integration**: Linked `style.css` across all project HTML files (`index.html`, `about.html`, `services.html`, `enquiry.html`, `contact.html`).
###Part 3 Update
  - Integrated client-side JavaScript form validation for enquiry and contact forms.
  - Implemented real-time dynamic keyword filtering/search functionality on `services.html`.
  - Added on-page SEO meta tags (`title`, `description`, `keywords`) across all web pages.
  - Configured script linking with `defer` for performance optimization