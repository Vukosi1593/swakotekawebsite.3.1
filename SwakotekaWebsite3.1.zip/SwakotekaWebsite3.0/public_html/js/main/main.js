/* 
 * Handles form validation, dynamic filtering, and interactivity.
 */

document.addEventListener("DOMContentLoaded", function () {
    // --- 1. Dynamic Content Search / Filter for Programs Page ---
    const searchInput = document.getElementById("programSearch");
    if (searchInput) {
        searchInput.addEventListener("keyup", function () {
            const filter = searchInput.value.toLowerCase();
            const cards = document.querySelectorAll(".program-card");

            cards.forEach(card => {
                const title = card.querySelector("h2").textContent.toLowerCase();
                const description = card.querySelector("p").textContent.toLowerCase();
                if (title.includes(filter) || description.includes(filter)) {
                    card.style.display = "";
                } else {
                    card.style.display = "none";
                }
            });
        });
    }

    // --- 2. Enquiry Form Validation ---
    const enquiryForm = document.getElementById("enquiryForm");
    if (enquiryForm) {
        enquiryForm.addEventListener("submit", function (event) {
            const fullName = document.getElementById("fullName").value.trim();
            const email = document.getElementById("email").value.trim();
            let errorMessage = "";

            if (fullName === "") {
                errorMessage += "Full Name is required.\n";
            }
            if (email === "" || !email.includes("@")) {
                errorMessage += "A valid email address is required.\n";
            }

            if (errorMessage !== "") {
                alert("Please correct the following errors:\n\n" + errorMessage);
                event.preventDefault(); // Stop form submission
            } else {
                alert("Thank you! Your enquiry has been successfully validated and processed.");
            }
        });
    }

    // --- 3. Contact Form Validation ---
    const contactForm = document.getElementById("contactForm");
    if (contactForm) {
        contactForm.addEventListener("submit", function (event) {
            const contactName = document.getElementById("contactName").value.trim();
            const contactMessage = document.getElementById("contactMessage").value.trim();
            let errorMessage = "";

            if (contactName === "") {
                errorMessage += "Name is required for contact messages.\n";
            }
            if (contactMessage.length < 10) {
                errorMessage += "Your message must be at least 10 characters long.\n";
            }

            if (errorMessage !== "") {
                alert("Form Validation Failed:\n\n" + errorMessage);
                event.preventDefault();
            } else {
                alert("Your message has been compiled and is ready for dispatch!");
            }
        });
    }
});